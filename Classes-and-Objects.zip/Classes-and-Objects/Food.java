/*
  Food
	Food object that takes acctributes of certian food and adds total price
	Dillon Quick	
	ISC4U1
	Nov 12 2021
	*/
public class Food {
  private double total = 0;
  private double price;
  public double fat;
  public double carbs;
  public double fiber;

/*
  Paramiters for each indivual fool variable 
  Dillon Quick	
	ISC4U1
	Nov 12 2021
*/

  Food (double Nprice, double Nfat, double Ncarbs, double Nfiber){
    price = Nprice; //declares the paraminters of indivual foods
    fat = Nfat;
    carbs = Ncarbs;
    fiber = Nfiber;
  }

/*
  Finds total for all the food
  Dillon Quick	
	ISC4U1
	Nov 12 2021
*/

  public void total (int count) {
    total = total + price * count; //adds total of food
  }

  public double returnTotal (){
    return (total); //returns total
  }
}
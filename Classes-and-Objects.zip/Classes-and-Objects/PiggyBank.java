/*
  PiggyBank
	Creates PiggyBank object where coins can be added and taken away with calaculating total and showing the selction screen
	Dillon Quick	
	ISC4U1
	Nov 12 2021
	*/
public class PiggyBank {
  private static double total = 0;
  
  /*
	Displays what number to enter to do what action.
	Dillon Quick	
	ISC4U1
	Nov 12 2021
	*/ 
  public void showSelection(){
    System.out.println ("");  //displays selection 
    System.out.println ("1. Show total in bank.");
    System.out.println ("2. Add a penny.");
    System.out.println ("3. Add a nickel.");
    System.out.println ("4. Add a dime.");
    System.out.println ("5. Add a quarter.");
    System.out.println ("6. Take money out of bank.");
    System.out.println ("Enter 0 to quit");
    System.out.print   ("Enter your choice: ");
  }
  public double total (){
    return (total); //returns total
  }

  public void showTotal(){
    System.out.printf ("Your Total Is: $" + ("%.2f"), total); //displays total
    System.out.println ("");
  }

  /*
	Adds coin to bank
	Dillon Quick	
	ISC4U1
	Nov 12 2021
	*/
  public void addCoin (double coin){
    total = total + coin; //calculates total
  }

  /*
	Takes Amount entered away from Bank
	Dillon Quick	
	ISC4U1
	Nov 12 2021
	*/
  public void takeCoin (double coin){
    if (coin > total) { //if else statement to determine is user is eligable to take funds
      System.out.println ("Not Enough Funds");  
    }
    
    else {
      total = total - coin;
    }
  }
}
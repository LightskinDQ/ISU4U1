/*
Java Program for OOP
OOP
Dillon Quick
ICS4U1
October 15, 2021
 */
import java.util.Scanner;
class Main {
  public static void main(String[] args) {
    Scanner in = new Scanner(System.in);
    int qCount = 0;
    String cont = "yes"; // variable that defines if the loop repeats
    int choice;
    while (!cont.equals("no"))   //loop that asks for what question to see
    {
      System.out.println("Please type which question you want to see: ");// displays options they can choose from
      System.out.println("1. Piggy Bank");
      System.out.println("3. Food");
      System.out.println("5. Game of Nim");
      choice = in.nextInt();
      switch (choice) { // created switch statement for the user to choose which question they want to do
        case 1: 
        MySavings();
        qCount++;
        break;
        case 3: 
        LunchOrder();
        qCount++;
        break;
        case 5: 
        Nim2();
        qCount++;
        break;
        default: // created default option showing if they pick a wrong number they will be sent back into the loop to choose a number listed in the optiond
        System.out.println("You didnt choose a number that corresponds to the options...");
      }
      System.out.println("");
      System.out.println("If you want to do another quesiton type yes");
      cont = in.next().toLowerCase();// makes sure user wants to do another question
    }
    System.out.println("You did " + qCount +" questions. Have a good day :)");//if user said anything other than no the program will end witht he number of quesitons they did
  }

  /*
	Method which allows users to add coins and take money out of a piggy bank object.
	Dillon	
	ISC4U1
	Nov 12 2021
	*/
  public static void MySavings (){
    Scanner in = new Scanner(System.in);
   int choice = 1; 
   PiggyBank bank = new PiggyBank(); //creates piggybank object
    bank.showSelection(); //shows the selection to see what the user wants to do with the piggy bank
    choice = in.nextInt();
    double take = 0; // variable for amount to take from bank
    do {                       
      switch (choice){                      
        case 1:  bank.showTotal(); //shows total inside bank
        break;
        case 2: bank.addCoin(0.01); //adds a penny to bank
        break;
        case 3: bank.addCoin(0.05); //adds a nickle to bank
        break;
        case 4: bank.addCoin(0.1); //adds a dime to bank
         break;
        case 5: bank.addCoin(0.25); //adds a quarter to bank
        break;
        case 6: 
          System.out.printf ("Your current total is: $" + ("%.2f"), bank.total()); //displays total so user knows how much to take out
          System.out.println("");
          System.out.println ("How much would you like to take out? $");
          take = in.nextDouble();
          bank.takeCoin(take); // takes out specified amount
        break;
      }
      bank.showSelection(); //show the selection again
      choice = in.nextInt();
    }  
    while (choice != 0);   
  }

  /*
	Lunch order application which prompts user how much food they want and displays attributes of food and total price.
	Dillon Quick
	ISC4U1a
  Nov 12 2021
	*/
  public static void LunchOrder (){
    Scanner in = new Scanner(System.in);
    int count;
    Food burger = new Food(1.85, 9, 33, 1); //creates ham object
    Food salad = new Food(2, 1, 11, 5); //creates salad object
    Food fries = new Food(1.30, 11, 36, 4); // creates french fries object
    Food soda = new Food(0.95, 0, 38, 0); //creates soda object
    System.out.print ("Enter Number of Burgers: ");
    count = in.nextInt();
    System.out.println ("Each hamburger has: " + burger.fat + "g of fat, " + burger.carbs + "g of carbs, and " + burger.fiber + "g of fiber."); //shows whats in hamburger
    System.out.println ("");
    burger.total(count);
    System.out.print ("Enter Number of Salads: ");
    count = in.nextInt();
    System.out.println ("Each salad has: " + salad.fat + "g of fat, " + salad.carbs + "g of carbs, and " + salad.fiber + "g of fiber."); //shows whats in salad
    System.out.println ("");
    salad.total(count);
    System.out.print ("Enter Number of Fries: ");
    count = in.nextInt();
    System.out.println ("French fries have: " + fries.fat + "g of fat, " + fries.carbs + "g of carbs, and " + fries.fiber + "g of fiber."); //shows whats in fries
    System.out.println ("");
    fries.total(count);
    System.out.print ("Enter Number of Sodas: ");
    count = in.nextInt();
     System.out.println ("Each soda has: " + soda.fat + "g of fat, " + soda.carbs + "g of carbs, and " + soda.fiber + "g of fiber."); //shows whats in soda
    System.out.println ("");
    soda.total(count);
    double total = burger.returnTotal() + soda.returnTotal() + fries.returnTotal() + salad.returnTotal(); //adds up all the total to create final total
    System.out.printf ("Your order has come to: $" + ("%.2f"),total); //displays total and rounds to 2 decimal places
  }

  /*
	Nim game which puts user against computer using rock object to keep track of total rocks
	Dillon Quick	
	ISC4U1
	Nov 12 2021
	*/
  public static void Nim2 (){
    Scanner in = new Scanner(System.in);
    int choice = 0;
    int random = 0;
    random = (int)(Math.random() * (30 - 15 + 1) + 15); //creates random amount of rocks 
    Rock r = new Rock(random); //creates rock object
    System.out.println ("There is " + r.rocks + " rocks to start from."); 
    while (r.rocks != 1 && r.rocks != 0) //while loop to repeat game until winner or loser
    {
      System.out.println ("");
      System.out.println ("Pick a number from 1-3 for how many rocks you want to take");
      choice = in.nextInt(); //select rocks
      if (r.rocks == 3 && choice == 3){
        System.out.println("You cant pick " + choice + ". Please pick another number");
        while (choice >= 3){
          System.out.println ("Select an appropriate number");
          choice = in.nextInt(); //select rocks
        }
      }
      if (r.rocks == 2 && choice == 2){
        System.out.println("You cant pick " + choice + ". Please pick another number");
        while (choice >= 2){
          System.out.println ("Select an appropriate number");
          choice = in.nextInt(); //select rocks
        }
      }
      r.TakeRock(choice); //takes rock from object
      System.out.println ("There are " + r.rocks + " rocks remaning.");
      do{//do while loop to make sure the computer takes the right amount of rocks in later rounds
      random = (int)(Math.random() * (3 - 1 + 1) + 1);//random rock
      }
      while(random > r.rocks);
      r.TakeRock(random); // takes rock from object
      System.out.println ("Computer picks " + random + " rocks.");
      System.out.println ("There are " + r.rocks + " rocks remaning.");
    }
    
    if (r.rocks == 1){ // if statement to determine if user won of losed
      System.out.println ("");
      System.out.println ("Wow you lost...");
    }
    else {
      System.out.println ("");
      System.out.println ("Impressive Congrats!");
    }  
  }
}
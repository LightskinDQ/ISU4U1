/*
  Rock
	Creates rock object where rocks can be taken away for nim game.
	Dillon Quick	
	ISC4U1
	Nov 12 2021
	*/
public class Rock {
  int rocks; //initlaizes the amount of rocks

/*
  Sets Paramiters for rock Variable
  Dillon Quick	
	ISC4U1
	Nov 12 2021
*/
  Rock (int newRocks){
    rocks = newRocks; //declares amount of rocks
  }
	
/*
  Takes rock away from original amount of rocks and checks if user is eligable
  Dillon Quick	
	ISC4U1
	Nov 12 2021
*/
  public void TakeRock(int num){ 
    if (num <= 3 && num > 0 && num <= rocks){ //if statement to detemine is user is eligable to take rocks
      rocks = rocks - num; 
    }
    else {
      System.out.println ("You took too many rocks try again");
    }
  }
}

public class Cards{

  public int card1 = 0;
  public int card2 = 0;
  public int card3 = 0;
  public int cccard1 = 0;
  public int cccard2 = 0;

  

}
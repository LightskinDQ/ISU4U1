import java.util.Scanner;
import java.util.Random;
/*
Java Program for Conditional Structure
Chapter 5
Dillon Quick
ICS4U1
October 1, 2021
 */
class Main {
  public static void main(String[] args) {
     Scanner in = new Scanner(System.in);
       int qCount = 0;
    int choice = 0;
    String cont = "yes"; //Set variables 
    while (cont.equals("yes")){ //created loop so the user cna do more than 1 question
    System.out.println("Please type which question you want to see: ");//displays options they can choose from
    System.out.println("1. Printing");
    System.out.println("4. Car Recall");
    System.out.println("5. Grade");
    System.out.println("6. Math Tutor");
    System.out.println("9. Guessing Game");
    choice = in.nextInt();
    switch (choice){// created switch statement for the user to choose which question they want to do
        case (1):
          int answer1 = question1(qCount);  
          qCount++;
          break;
          case (4):
          int answer4 = question4(qCount); 
          qCount++;
          break;
          case (5):
          int answer5 = question5(qCount); 
          qCount++;
          break;
          case (6):
          int answer6 = question6(qCount);
          qCount++;
          break;
          case (9):
          int answer9 = question9(qCount); 
          qCount++;
          break;
          default:// created default option showing if they pick a wrong number they will be sent back into the loop to choose a number listed in the optiond
              System.out.println("You didnt choose a number that corresponds to the options...");
          
    }
    System.out.println("If you want to do another quesiton type yes");
    cont = in.next().toLowerCase();// makes sure user wants to do another question
    }
    System.out.println("You did " + qCount +" questions. Have a good day :)");//if user said anything other than no the program will end witht he number of quesitons they did
  
    }// main class
    public static int question1(int qCount){ //Question 1
        Scanner in = new Scanner(System.in);
        double copies = 0;
        double total = 0; // create variables
        System.out.println("Enter the number of copies you want to be printed");
        copies = in.nextInt();
        
        if (copies >=0 && copies <= 99){ // created if statements to determine the value for each copy depending on the number they inputted
            System.out.println("Price per copies is: $0.30");
            total = copies * 0.30;// calculate total
            System.out.println("Total cost is: $" + total);
        }
        if (copies >= 100 && copies <= 499){  // created if statements to determine the value for each copy depending on the number they inputted
            System.out.println("Price per copies is: $0.28");
            total = copies * 0.28; // calculate total
                        System.out.println("Total cost is: $" + total);
        }
        if (copies >= 500 && copies <= 749){  // created if statements to determine the value for each copy depending on the number they inputted
            System.out.println("Price per copies is: $0.27");
            total = copies * 0.27;// calculate total
                        System.out.println("Total cost is: $" + total);
        }
        if (copies >= 750 && copies <= 1000){  // created if statements to determine the value for each copy depending on the number they inputted
            System.out.println("Price per copies is: $0.26");
            total = copies * 0.26;//calculate total
                        System.out.println("Total cost is: $" + total);
        }
        if (copies > 1000){  // created if statements to determine the value for each copy depending on the number they inputted
            System.out.println("Price per copies is: $0.25");
            total = copies * 0.25;//calculate total
                        System.out.println("Total cost is: $" + total);
        }
        
        qCount++;
return qCount;
    }
     public static int question4(int qCount){ //Question 4
        Scanner in = new Scanner(System.in);
        int cNum = 0;
        System.out.println("Enter the car's model number");// asks user for what number thier car model is
        cNum = in.nextInt();
        if (cNum == 119 || cNum == 179 || cNum == 189 || cNum == 195 || cNum == 221 || cNum == 780 ){// if statement too see if thier car model matches with one of these numbers
            System.out.println("Your car is not defective");// if numbers match then this statement will pbe printed
        }
        else;
        System.out.println("Your car is defective. It must be repaired.");// else statement for any other option inputted
        
        qCount++;
return qCount;
     }
    public static int question5(int qCount){ //Question 5
        Scanner in = new Scanner(System.in);
        int perc = 1000;
        while (perc > 100){
        System.out.println("Enter the Percentage: "); // asks user for what thier percent is and if the number is higher than 100, they will be aksed the same quesiton until they get it right
        perc = in.nextInt();
        }
        
        if (perc >= 90 && perc <= 100){// if statements to determine which grade they get
            System.out.println("The corresponding letter grade is: A");
        }
        if (perc >= 80 && perc <= 89){// if statements to determine which grade they get
            System.out.println("The corresponding letter grade is: B");
        }
        if (perc >= 70 && perc <= 79){// if statements to determine which grade they get
            System.out.println("The corresponding letter grade is: C");
        }
        if (perc >= 60 && perc <= 69){// if statements to determine which grade they get
            System.out.println("The corresponding letter grade is: D");
        }
        if (perc < 60){// if statements to determine which grade they get
            System.out.println("The corresponding letter grade is: F");
        }
        
        qCount++;
return qCount;
}
    public static int question6(int qCount){ //Question 6
        Scanner in = new Scanner(System.in);
        String[] arr = {"+", "-", "/", "*"}; // creates array of inputs for question
        double ans = 0;
        double guess = 0;
        Random r = new Random();
        int rNum = r.nextInt(arr.length);
        double rNum1 = (int)(Math.random() * (10 - 1 + 1) + 1);
        double rNum2 = (int)(Math.random() * (10 - 1 + 1) + 1);// creates random number generator

        if (arr[rNum].equals("+")){
            ans = rNum1 + rNum2;// checks to see what symbol is randomly generated and makes an equation for it
        }
        else if (arr[rNum].equals("-")){
            ans = rNum1 - rNum2; // checks to see what symbol is randomly generated and makes an equation for it
        }
        else if (arr[rNum].equals("*")){
            ans = rNum1 * rNum2; // checks to see what symbol is randomly generated and makes an equation for it
        }
        else if (arr[rNum].equals("/")){
            ans = rNum1 / rNum2; // checks to see what symbol is randomly generated and makes an equation for it
        }
        System.out.println("What is "+ rNum1 +" " + arr[rNum] + " "+ rNum2);
        guess = in.nextDouble(); // asks user question and asks for an answer
        if (guess == ans){
            System.out.println("Correct!");
        }
        if (guess != ans){
            System.out.println("Incorrect!");
        }// checks to see if it correct or incorrect
 
        qCount++;
return qCount;

}
    public static int question9(int qCount){ //Question 9
        Scanner in = new Scanner(System.in);
    int gNum = 0;
    int choice = 1;
    int count = 0;
    String cont1 = "yes";//Set variables 
    while (cont1.equals("yes")){ //created loop so the user cna do more than 1 question
    System.out.println("Choose which difficulty you want to play on: ");//displays options they can choose from
    System.out.println("1. Easy");
    System.out.println("2. Medium");
    System.out.println("3. Hard");
    choice = in.nextInt();
    switch (choice){// created switch statement for the user to choose which difficulty they want to do
        
        case (1):// easy
            int rNum = (int)(Math.random() * (20 - 1 + 1) + 1);// create random number depending on which difficulty they choose
             System.out.println("Guess a number from 1-20");
    gNum = in.nextInt();// asks user for number
    System.out.println("Players number:" + gNum);
    System.out.println("Computer's number:" + rNum);
    
    if (gNum == rNum){
        System.out.println("You Win!");// if user guesses the right number then they willl get a winner display message
    }
    else if (gNum != rNum){
        System.out.println("Better luck next time."); // if user guesses the wrong number then they willl get a loser display message
    }
          break;
          
          case (2): //medium
              int rNum1 = (int)(Math.random() * (50 - 1 + 1) + 1);// create random number depending on which difficulty they choose
               System.out.println("Guess a number from 1-50");
    gNum = in.nextInt();
        System.out.println("Players number:" + gNum);
    System.out.println("Computer's number:" + rNum1);
    if (gNum == rNum1){
        System.out.println("You Win!");// if user guesses the right number then they willl get a winner display message
    }
    else if (gNum != rNum1){
        System.out.println("Better luck next time.");// if user guesses the wrong number then they willl get a loser display message
    }
          break;
          
          case (3):// hard
              int rNum2 = (int)(Math.random() * (100 - 1 + 1) + 1);// create random number depending on which difficulty they choose
              for (int i = 0 ; i < 3; i++){
                  System.out.println("Guess a number from 1-100, you will have 3 tries");
    gNum = in.nextInt();// user enters number
    if (count == 2){
                  System.out.println("Better luck next time");
                  break;// if the user guesses 3 times wrong this will break it out of the loop
              }
    if (gNum < rNum2){
        System.out.println("Guess higher");
        count++; // if the number is lower then it will display a guess higher message
    }
    else if (gNum > rNum2){
        System.out.println("Guess lower");
        count++; // if the number is higher then it will display a guess lower message
    }
    else if (gNum == rNum2){
        System.out.println("You win!");
        break; // if user guesses the right number then they willl get a winner display message
    }
              }  
          break;
          
          default:
              System.out.println("You didnt choose a number that corresponds to the options...");
              break; // if they choose another number thats not 1-3, then this will display a default message asking the user to pick a different mode
    }
    System.out.println("If you want to do another difficulty type yes");
    cont1 = in.next().toLowerCase();// makes sure user wants to do another question
    }
        qCount++;
return qCount;
}
}
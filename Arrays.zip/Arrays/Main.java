  /* 
  Arrays
  Dillon Quick	
	ICS4U1
	Dec 8 2021
  */
class Main {
  /*
	Main Method Sends to Main Display
	Dillon Quick	
	ICS4U1
	Dec 8 2021
	*/
  public static void main(String[] args) {
    Display d = new Display ();
    d.main();
  }
}
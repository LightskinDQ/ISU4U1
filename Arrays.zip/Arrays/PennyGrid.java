import java.util.ArrayList;
public class PennyGrid{
  public static int one = 0;
  public static int two = 0;
  public static int three = 0;
  public static int four = 0;
  public static int five = 0;
public void main(){
    int[][]grid = new int[5][5]; // creates grid and depending what number there is as a placeholder, it will change the grid
    for(int i = 0;i<3;i++){//random generation of the grid
      for(int j = 1;j<=5;j++){
        int rx = (int)(Math.random() * (4 - 0 + 1) + 0);
        int ry = (int)(Math.random() * (4 - 0 + 1) + 0);
        while(grid[rx][ry]!=0){
          rx = (int)(Math.random() * (4 - 0 + 1) + 0); 
          ry = (int)(Math.random() * (4 - 0 + 1) + 0);
        }
        grid[rx][ry] = j;
      }
    }
    ArrayList<Integer>list = new ArrayList<>();//list containing squares with penny
    for(int i = 0;i<10;i++){//random generation of the squares with penny
      int r = (int)(Math.random() * (24 - 0 + 1) + 0);
      while(list.contains(r)) 
      r = (int)(Math.random() * (24 - 0 + 1) + 0);
      list.add(r);
    }
    //output the grid
    for(int i = 0;i<5;i++){
      for(int j = 0;j<5;j++){
        String str = "";
        switch(grid[i][j]){
          case 0:
            str = ("[ empty ]");
            break;
          case 1:
            str = ("[ puzzle ]");
            break;
          case 2:
            str = ("[ game ]");
            break;
          case 3:
            str = ("[ ball ]");
            break;
          case 4:
            str = ("[ poster ]");
            break;
          case 5:
            str = ("[ doll ]");
            break;
        }
        int k = i*5+j;
        if(list.contains(k)){ //outputs name that coin hits in uppercase
          System.out.print(str.toUpperCase());
          switch (grid[i][j]){
            case 1: one++; break; //counts how many times one prize was hit
            case 2: two++; break;
            case 3: three++; break;
            case 4: four++; break;
            case 5: five++; break;
          }
        }
        else{
          System.out.print(str);
        }
      }
      System.out.println();
    }
}//main
}
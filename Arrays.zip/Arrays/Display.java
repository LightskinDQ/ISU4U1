  /*
	main method that conatins all code that asks user input on what question they want to see. 
	Dillon Quick	
	ICS4U1
	Dec 8 2021
	*/
  import java.util.Scanner;
  public class Display {
  public void main (){
    Scanner in = new Scanner (System.in);
    int qCount = 0;
    String cont = "yes"; //variable that defines if the loop repeats
    int choice;
    PennyPitch penn = new PennyPitch();
    RandomStats rand = new RandomStats();
    while (!cont.equals("no")){   //loop that asks for what question to see
      System.out.println("Please type which question you want to see: ");// displays options they can choose from
      System.out.println("1. Random Stats");
      System.out.println("2. Penny Pitch");
      choice = in.nextInt();
      switch (choice) {
        case 1: rand.main();
        qCount++;
        break;
        case 2: penn.main();
        qCount++;
        break;
        default: // created default option showing if they pick a wrong number they will be sent back into the loop to choose a number listed in the optiond
        System.out.println("You didnt choose a number that corresponds to the options...");
      }
      
      System.out.println("");
      System.out.println("If you want to do another quesiton type yes");
      cont = in.next().toLowerCase();// makes sure user wants to do another question
    }
    System.out.println("You did " + qCount +" questions. Have a good day :)");//if user said anything other than no the program will end witht he number of quesitons they did
    }
  }

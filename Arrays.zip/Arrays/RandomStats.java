/*
  RandomStats.java
	Shows frequency of how many time a number from 0 - 9 is picked when rolled 500 times
	Dillon Quick	
	ICS4U1
	Dec 8 2021
	*/
import java.util.Random;
import java.util.ArrayList;
public class RandomStats {
  /*
	main method contains all code to show frequency
	Dillon Quick	
	ICS4U1
	Dec 8 2021
	*/
  public void main() {
    int[][] array = new int[2][10]; // creates array
    int count = 0; 
    int rand = 0;
    for (int i = 0; i <= 9; i++){ // adds orginal numbers from 0 - 9 to coloum 0
      array[0][i] = count;
      count++;
    }
    for (int i = 1; i<= 500; i++){ //roles the number from 0 - 9 500 times and adds it to coloum 1
      rand = (int)(Math.random() * (9 - 0 + 1) + 0);
      count = -1;
      do {
        count = count + 1; 
        if (rand == count){
          array[1][count] = array[1][count] + 1; 
        }
      }
      while (rand != count);
    }
    System.out.println("Number  Occurrences");
    for (int i =0; i <= 9; i++){ //prints out output
      System.out.println (array [0][i] + "       " + array [1] [i]);
    }
}
}
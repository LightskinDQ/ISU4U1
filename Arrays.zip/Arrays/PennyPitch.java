/*
  PennyPitch.java
	Creates a PennyPitch game that randomly picks if the user recieves prizes or not
	Dillon Quick	
	ICS4U1
	Dec 8 2021
	*/

import java.util.Random;
import java.util.ArrayList;
public class PennyPitch extends PennyGrid{
  /*
	main method contains all code that creates penny pitch game
	Dillon Quick	
	ICS4U1
	Dec 8 2021
	*/
  public void main(){
    PennyGrid p = new PennyGrid();
    p.main();

    if (PennyGrid.one == 3){
      System.out.println ("You Won a Puzzle!"); //displays if won
    }
    if (PennyGrid.two == 3){
      System.out.println ("You Won a Game!");
    }
    if (PennyGrid.three == 3){
      System.out.println ("You Won a Ball!");
    }
    if (PennyGrid.four == 3){
      System.out.println ("You Won a Poster!");
    }
    if (PennyGrid.five == 3){
      System.out.println ("You Won a Doll!");
    }
    else{
      System.out.println("You got nothing :( Better luck next time!");
    }
  }
}


import java.util.Scanner;
import java.util.Arrays;
/*
Java Program for Loops
Chapter 6
Dillon Quick
ICS4U1
October 1, 2021
 */
class Main {
  public static void main(String[] args) {
    Scanner in = new Scanner(System.in);
    int qCount = 0;
    int choice = 0;
    String cont = "yes"; //Set variables 
    while (cont.equals("yes")){ //created loop so the user cna do more than 1 question
    System.out.println("Please type which question you want to see: ");//displays options they can choose from
    System.out.println("1. Prime Number");
    System.out.println("5. Digits Display");
    System.out.println("6. Digits Sum");
    System.out.println("11. Elapsed Time Calculator");
    System.out.println("18. Monogram");
    System.out.println("20. Count Vowels");
    choice = in.nextInt();
    switch (choice){// created switch statement for the user to choose which question they want to do
        case (1):
          int answer1 = question1(qCount);  
          qCount++;
          break;
          case (5):
          int answer5 = question5(qCount); 
          qCount++;
          break;
          case (6):
          int answer6 = question6(qCount); 
          qCount++;
          break;
          case (11):
          int answer11 = question11(qCount);
          qCount++;
          break;
          case (18):
          int answer18 = question18(qCount); 
          qCount++;
          break;
          case (20):
          int answer20 = question20(qCount);
          qCount++;
          break;
          default:// created default option showing if they pick a wrong number they will be sent back into the loop to choose a number listed in the optiond
              System.out.println("You didnt choose a number that corresponds to the options...");
          
    }
    System.out.println("If you want to do another quesiton type yes");
    cont = in.next().toLowerCase();// makes sure user wants to do another question
    }
    System.out.println("You did " + qCount +" questions. Have a good day :)");//if user said anything other than no the program will end witht he number of quesitons they did
    
    
    
      }//main method
     public static int question1(int qCount){//Question 1
         Scanner in = new Scanner(System.in);
         System.out.println("Welcome to Question 1 a)");
int num = -1;
int num1 = 0;
int num2 = 0;// set variables
while (num < 0){// makes sure that the number put is a positive number and if they dont then they will be stuck in this loop
System.out.println("Enter a positive integer");
            num = in.nextInt();
            if (num > 0){
                break;
            }
    }    
if (num == 1){// makes sure that 1 isnt a prime number
    System.out.println("This is not a prime number");
}
if (num == 2 || num == 3){// if the user put in one of these numbers then it would default to that nnumber being prime number due to the restrictions later int he question 
    System.out.println("This is a prime number");
}
else if (num % 2 == 0 || num % 3 == 0){// if its perfecly divisable by 2 or 3, then it isnt a prime number
    System.out.println("This isnt a prime numbers");
}
else if (num % 2 != 0 || num % 3 != 0){ // if there is a remainder that means it cant be divided by 2 or 3 mamking it a prime number
    System.out.println("This is a prime number");
} 
System.out.println("Welcome to Question 1 b)");
System.out.println("Please enter a number");
num1 = in.nextInt();
System.out.println("Please enter another number");
num2 = in.nextInt();//user enters 2 numbers 
System.out.println("These are all the prime numbers: ");
for (int i = num1 ; i < num2 + 1; i++){// for loop with appropriate restrictions. in the loop the counter will start at the first inputed number and then go through all the numbers until it reaches the second inputted number
if (i == 2 || i == 3){// if the number is 2 or 3 then it will be a prime number
System.out.println(i);
}
else if (i % 2 == 0 || i % 3 == 0 || i == 1){  // if its perfecly divisable by 2 or 3, then it isnt a prime number 
}
else if (i % 2 != 0 || i % 3 != 0){// if there is a remainder that means it cant be divided by 2 or 3 making it a prime number
System.out.println(i);
}    
}
qCount = qCount + 1;
return qCount;
     }
     
     public static int question5(int qCount){//Question 5
          System.out.println("Welcome to Question 5");
         Scanner in = new Scanner(System.in);
         int num = -1;// set to -1 for the loop to work
while (num < 0){//loop to ensure that the user enters a positive number or anything higher than -1
            System.out.println("Enter a positive integer");
            num = in.nextInt();
            if (num > 0){
                break;
            }
    }     
String num1 = "" + num; // converts the integer num into a string 
         for(int i = 0; i < num1.length(); i++) { //loop to print the exact number of numbers in the inputed number
             System.out.println(num1.charAt(i));// prints a number based on which number the lenth of the number is on
         } 
         qCount = qCount + 1;
return qCount;
     }
     
     public static int question6(int qCount){//Question 6
         Scanner in = new Scanner(System.in);
          System.out.println("Welcome to Question 6");
         int num = -1;
int total  = 0;
while (num < 0){ //loop to ensure that the user enters a positive number or anything higher than -1
            System.out.println("Enter a positive integer");
            num = in.nextInt();
            if (num > 0){
                break;
            }
    }
int length = String.valueOf(num).length(); // finds length of number inputted
String num1 = Integer.toString(num); // converts number inputted int string

for(int i = 0; i < length; i++){
    char num2 = num1.charAt(i); // finds the index value of the number 
    
    String num3 =String.valueOf(num2); // converts char into string
    
    int number = Integer.valueOf(num3); // converts string into int
    total = total + number; // total of digit

}
System.out.println("The sum of the digits is " + total); // prints total
         qCount = qCount + 1;
return qCount;
     }
     
     public static int question11(int qCount){//Question 11
         Scanner in = new Scanner(System.in);
          System.out.println("Welcome to Question 11");
         int hour = 0;
    int eHour = 0;
    int tHour = 0;
    String time = "";// set variables
    System.out.println("Enter the starting hour: ");
    hour = in.nextInt();// user enters the time they want
    while (!time.equals("am") || !time.equals ("pm")){// loop to make sure that the user only enters am or pm and if they enter anything otherwise they will be asked until they put in the right input
            System.out.println("Enter am or pm");
            time = in.next().toLowerCase();
            if (time.equals("am") || time.equals ("pm")){
                break;
            }
    }
    System.out.println("Enter the number of elapsed hours: ");
    eHour = in.nextInt();// enter the time passed
    
    tHour = hour + eHour;// adds the time to see what time it will be
    if (tHour > 12 && tHour <= 24){
        if (time.equals("am")){
            time = "pm";
        }
        else if (time.equals("pm")){
            time = "am";
        }
    }// if the hour goes over 12, the time of day will change based on what they put before. if they put am and its over 12h, then the time of day will change to p and vise versa
        if (tHour > 24){ //converts time 
                tHour = tHour - 24;
            }
            else if (tHour > 12 && tHour <= 24){// converts time
                tHour = tHour - 12;
            }
            
        // you cant have more than 12h on a clock so you need to subtract 12 in order to find the time
System.out.println("The time is: " + tHour + " " + time);   

         qCount = qCount + 1;
return qCount;
     }
     public static int question18(int qCount){//Question 18
         Scanner in = new Scanner(System.in);
          System.out.println("Welcome to Question 18");
 
         String fName = "";
    String mName = "";
    String lName = "";// create variables
    System.out.println("Please input your first name");
    fName = in.next().toLowerCase();
    System.out.println("Please input your middle name");
    mName = in.next().toLowerCase();
    System.out.println("Please input your last name");
    lName = in.next().toUpperCase(); // gets inputs for first, midle and last name
    int phraseLength1 = fName.length();
    char index = fName.charAt(0); // finds length of name and pics the first letter of the name
    int phraseLength2 = mName.length();
    char index1 = mName.charAt(0); // finds length of name and pics the first letter of the name
    int phraseLength3 = lName.length();
    char index2 = lName.charAt(0); // finds length of name and pics the first letter of the name
    System.out.println("Your monogram is: " + index + index2 + index1); // prints in order of what the question wants

         qCount = qCount + 1;
return qCount;
     }
     public static int question20(int qCount){//Question 20
         Scanner in = new Scanner(System.in);
          System.out.println("Welcome to Question 20");
         String answer = "";
    int count = 0; // set variables
    System.out.println("Enter Text: ");
    answer = in.nextLine();
    int pLength = answer.length(); // checks the lenth of the word
    for (int i = 0 ; i < pLength; i++){// for loop is created so the program will go through every letter of whatever is typed and will check to see if its a vowel or not. 
        if (answer.charAt(i) == 'a' || answer.charAt(i) == 'e' || answer.charAt(i) == 'i' || answer.charAt(i) == 'o' || answer.charAt(i) == 'u'|| answer.charAt(i) == 'A' || answer.charAt(i) == 'E' || answer.charAt(i) == 'I' || answer.charAt(i) == 'O' || answer.charAt(i) == 'U'){
            count++;// if the certain letter of the word is a vowel, it will be accounted for
     }
}
    System.out.println("The number of vowels in the word, " + answer + " is: " + count);// prints the number of vowels in the word inputted
         qCount = qCount + 1;
return qCount;
     }
     }
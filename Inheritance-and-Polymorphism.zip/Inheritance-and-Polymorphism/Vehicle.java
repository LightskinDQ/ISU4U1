/*
	Vehicle
	Dillon Quick	
  ICS4U1
  Nov 26 2021
  */
abstract class Vehicle {
  String color;
  int seats;
  int wheels;
  double milage;
/*Constructor to pass all of the atributes of a car
Dillon Quick	
ICS4U1
Nov 26 2021
*/

 Vehicle (String newcolor, int newseats, int newwheels, double newmilage) {
    color = newcolor;
    seats = newseats;
    wheels = newwheels;
    milage = newmilage;
  }

//Create functions of a vehicle that can be passed for every type of vehicle
  public void drive (){
    System.out.println("Vroom Vroom");
  }
  public void openDoor(){
    System.out.println("Door has been opened");
  }
  public void closeDoor(){
    System.out.println("Door has been closed");
  }
  public void park(){
    System.out.println("The car has stopped and been parked");
  }
}


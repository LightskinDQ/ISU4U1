  /*
	Car
	Dillon Quick	
  ICS4U1
  Nov 26 2021
  */
public class Car extends Vehicle {
  /*
	constructor that takes everything needed to send to vehicle
	Dillon Quick	
  ICS4U1
  Nov 26 2021
  */
  Car (String color, int seats, int wheels, double milage){
    super (color,seats,wheels,milage);
  }
  
  /*
  atribute of a car different to any other vehicle is it plays music os only this atribute will be attached to this type of vehicle
  Dillon Quick	
  ICS4U1
  Nov 26 2021
  */
  public void music(){
    System.out.println("Now playing music");
  }
}
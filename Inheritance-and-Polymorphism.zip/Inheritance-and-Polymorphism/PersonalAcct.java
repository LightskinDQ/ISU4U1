/*
  PersonalAcct
	Object that creates the PersonalAcct
	Dillon Quick
	ICS4U1
  Nov 26 2021
	*/
public class PersonalAcct extends Account {
  /*
	constructor that takes everything needed to send to account
	Dillon Quick
	ICS4U1
  Nov 26 2021
	*/
 PersonalAcct (double bala, String firstName, String lastName,String string, String citys, String country, String zips) {
  super(bala, firstName, lastName, string, citys, country, zips);
 }
   /*
	checks if fee is needed to be applied
	Dillon Quick
	ICS4U1
  Nov 26 2021
	*/
  private void checkBalance () {
    if (balance < 100){
      System.out.println ("Does not meet sufficient amount in balance. Fee of $2 will be applied.");
      balance = balance - 2;
    }
  }

  
  /*
	withdraw method which withdraws money from account
	Dillon Quick
	ICS4U1
  Nov 26 2021
	*/
  public void withdraw(double amt) {
    super.withdraw(amt);
    checkBalance();
  }

  
  /*
	deposit method which deposits money into account
	Dillon Quick
	ICS4U1
  Nov 26 2021
	*/
  public void deposit (double amt) {
    super.deposit(amt);
    checkBalance();
  }
}
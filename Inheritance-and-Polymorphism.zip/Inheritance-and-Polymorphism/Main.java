/*
	Main
	Dillon Quick	
  ICS4U1
  Nov 26 2021
  */
  import java.util.Scanner;
class Main {
  public static void main(String[] args) {
    Scanner in = new Scanner(System.in);
    int qCount = 0;
    String cont = "yes"; // variable that defines if the loop repeats
    int choice;
    while (!cont.equals("no"))   //loop that asks for what question to see
    {
      System.out.println("Please type which question you want to see: ");// displays options they can choose from
      System.out.println("1. Bank");
      System.out.println("2. Vehicle Picker");
      choice = in.nextInt();
      switch (choice) { // created switch statement for the user to choose which question they want to do
        case 1: 
        Question2();
        qCount++;
        break;
        case 2: 
        Question3();
        qCount++;
        break;
        default: // created default option showing if they pick a wrong number they will be sent back into the loop to choose a number listed in the optiond
        System.out.println("You didnt choose a number that corresponds to the options...");
      }
      System.out.println("");
      System.out.println("If you want to do another quesiton type yes");
      cont = in.next().toLowerCase();// makes sure user wants to do another question
    }
    System.out.println("You did " + qCount +" questions. Have a good day :)");//if user said anything other than no the program will end witht he number of quesitons they did
  }
/*
Sends to Question2ClientCode to do question
Dillon Quick
ISU4U1
Nov 26 2021
*/
  public static void Question2 (){
    Question2ClientCode Q2 = new Question2ClientCode();
    Q2.DisplayInput();
    do{
      Q2.DisplayInput2();
    }
    while (Q2.quit == 0);
    }
    /*
Sends to Question2ClientCode to do question
Dillon Quick
ISU4U1
Nov 26 2021
*/
  public static void Question3 (){
    Question3ClientCode Q3 = new Question3ClientCode();
    Q3.carType();
  }
  }
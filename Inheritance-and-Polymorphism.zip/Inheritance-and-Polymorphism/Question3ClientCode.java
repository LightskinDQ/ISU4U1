  /*
  Question3ClientCode
	Creates Display for Exercise 3
	Dillon Quick	
	ICS4U1
	Nov 26 2021
	*/
import java.util.Scanner;
public class Question3ClientCode {
  Scanner in = new Scanner(System.in);
  static String color;
  static int seats;
  static int wheels;
  static double milage;
  static int quit = 0;
  /*
	Ask for what vehicle user has
	Dillon Quick	
	ICS4U1
	Nov 26 2021
	*/

  public void carType() {
    System.out.println("What type of vehicle do you want");
    System.out.println("1. Car");
    System.out.println("2. Mini Van");
    System.out.println("3. Truck");
    int choice = in.nextInt();
    switch (choice) {
      case 1:
      atriutes();
      carActions();
      break;
      case 2:
      atriutes();
      miniVanActions();
      break;
      case 3:
      atriutes();
      truckActions();
      break;
    }
  }
 /*
	Asks for attributes from user
	Dillon Quick	
	ICS4U1
	Nov 26 2021
	*/

  public void atriutes() {
    System.out.println("What Color is the colour of the car?");
    color = in.next();
    System.out.println("How many seats does your car have");
    seats = in.nextInt();
    System.out.println("How many wheels does your car have?");
    wheels = in.nextInt();
    System.out.println("Whats Your car's Milage?");
    milage = in.nextDouble();
  }

  /*
	Ask attributes of truck from user and displays what the user wants to do with the truck
	Dillon Quick	
	ICS4U1
	Nov 26 2021
	*/

public void truckActions(){
  while (quit == 0){
  System.out.println("What do you want to do");
  System.out.println ("1. Open Door");
  System.out.println ("2. Close Door");
  System.out.println ("3. Drive Car");
  System.out.println ("4. Stop Car");
  System.out.println ("5. Attach Extention");
  System.out.println ("6. Dettach Extention");
  System.out.println ("7. Quit");
  Truck t = new Truck(color, seats, wheels, milage);
  int choice = in.nextInt();
switch (choice){
  case 1:
  t.openDoor();
  break;
  case 2:
  t.closeDoor();
  break;
  case 3:
  t.drive();
  break;
  case 4:
  t.park();
  case 5:
  t.attachExtention();
  break;
  case 6:
  t.dettachExtention();
  break;
  case 7:
  quit = 1;
  break;
    }
  }
}
/*
	Ask attributes of minivan from user and displays what the user wants to do with the minivan
	Dillon Quick	
	ICS4U1
	Nov 26 2021
	*/
public void miniVanActions(){
  while (quit == 0){
  System.out.println("What do you want to do");
  System.out.println ("1. Open Door");
  System.out.println ("2. Close Door");
  System.out.println ("3. Drive Car");
  System.out.println ("4. Stop Car");
  System.out.println ("5. Open Trunk");
  System.out.println ("6. Close Trunk");
  System.out.println ("7. Quit");
  MiniVan m = new MiniVan(color, seats, wheels, milage);
  int choice = in.nextInt();
switch (choice){
  case 1:
  m.openDoor();
  break;
  case 2:
  m.closeDoor();
  break;
  case 3:
  m.drive();
  break;
  case 4:
  m.park();
  break;
  case 5:
  m.openTrunk();
  break;
  case 6:
  m.closeTrunk();
  break;
  case 7:
  quit = 1;
  break;
    }
  }
}

/*
	Ask attributes of car from user and displays what the user wants to do with the car
	Dillon Quick	
	ICS4U1
	Nov 26 2021
	*/
public void carActions(){
  while (quit == 0){
  System.out.println("What do you want to do");
  System.out.println ("1. Open Door");
  System.out.println ("2. Close Door");
  System.out.println ("3. Drive Car");
  System.out.println ("4. Stop Car");
  System.out.println ("5. Play music");
  System.out.println("6. Quit");
  Car c = new Car(color, seats, wheels, milage);
  int choice = in.nextInt();
switch (choice){
  case 1:
  c.openDoor();
  break;
  case 2:
  c.closeDoor();
  break;
  case 3:
  c.drive();
  break;
  case 4:
  c.park();
  break;
  case 5:
  c.music();
  break;
  case 6:
  quit = 1;
  break;
    }
  }
}
}



  /*
	MiniVan
	Dillon Quick	
  ICS4U1
  Nov 26 2021
  */
public class Truck extends Vehicle {
  /*
	constructor that takes everything needed to send to vehicle
	Dillon Quick	
  ICS4U1
  Nov 26 2021
  */
  Truck (String color, int seats, int wheels, double milage){
    super (color,seats,wheels,milage);
  }
  
  /*
  atribute of a MiniVan different to any other vehicle is it plays music os only this atribute will be attached to this type of vehicle
  Dillon Quick	
  ICS4U1
  Nov 26 2021
  */
  public void attachExtention(){
    System.out.println("The Truck now has extra storage to hold things");
  }
  public void dettachExtention(){
    System.out.println("The extra load has been unloaded");
  }
}
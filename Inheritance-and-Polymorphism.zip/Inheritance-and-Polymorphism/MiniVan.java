  /*
	MiniVan
	Dillon Quick	
  ICS4U1
  Nov 26 2021
  */
  public class MiniVan extends Vehicle {
  /*
	constructor that takes everything needed to send to vehicle
	Dillon Quick	
  ICS4U1
  Nov 26 2021
  */
  MiniVan (String color, int seats, int wheels, double milage){
    super (color,seats,wheels,milage);
  }
  
  /*
  atribute of a MiniVan different to any other vehicle is it plays music os only this atribute will be attached to this type of vehicle
  Dillon Quick	
  ICS4U1
  Nov 26 2021
  */
  public void openTrunk(){
    System.out.println("The trunk is now open");
  }
  public void closeTrunk(){
    System.out.println("The trunk is now closed");
  }
}
/*
  Exercise2Display.java
	Creates Display for Exercise 2
	Dillon Quick
  ISU4U1
  Nov 26 2021
	*/
import java.util.Scanner;
public class Question2ClientCode {
  static int acct;
  Scanner in = new Scanner(System.in);
  PersonalAcct PA;
  BuisnessAcct BA;
  int quit = 0;
   /*
	Displays Input
	Dillon Quick	
	ICS4U1
	Nov 26 2021
	*/
  public void DisplayInput () {
    System.out.print ("Enter Your First Name: ");
    String fname = in.next();
    System.out.print ("Enter Your Last Name: ");
    String lname = in.next();
    System.out.print ("Enter Your Street Name: ");
    String str = in.next();
    System.out.print ("Enter Your City Name: ");
    String city = in.next();
    System.out.print ("Enter Your Country Name: ");
    String country = in.next();
    System.out.print ("Enter Your Zip Code: ");
    String zip = in.next();
    System.out.println ("Enter What Account You Want to Input Balance Into:");
    System.out.println ("Enter 1 for Personal Account: ");
    System.out.println ("Enter 2 for Business Account: ");
    int account = in.nextInt();
    System.out.print ("Enter Amount of Balance You Want to Deposit: ");
    double bal = in.nextInt();

    switch (account) {
      case 1 : 
        acct = 1;
        PA = new PersonalAcct(bal, fname, lname, str, city, country, zip);
      break;
      case 2 : 
        acct = 2;
        BA = new BuisnessAcct(bal, fname, lname, str, city, country, zip);
      break;
    }
  }
   /*
	Displays second input screen
	Dillon Quick
  ISU4U1
  Nov 26 2021
	*/
  public void Display2 (){
    System.out.println ("What Do You Wish To Do?");
    System.out.println ("1. Get Balance");
    System.out.println ("2. Withdrawl");
    System.out.println ("3. Deposit");
    System.out.println ("4. Quit");
  }
  /*
	Gets second input from user
	Dillon Quick
  ISU4U1
  Nov 26 2021
	*/
  public void DisplayInput2 () {
    double withdraw;
    double deposit;
    quit = 0;
    Display2();
    int input = in.nextInt(); //asks the user for what they want to do and put thier action as a variable
    switch (input) {
      case 1: 
          switch (acct){
            //case 1 in the case is meant for if they do a personal acount and case 2 is if they do a buisness account
            case 1: System.out.println ("Your balance is: " + PA.getBalance()); // gets balance
              break;
            case 2: System.out.println ("Your balance is: " + BA.getBalance()); // gets balance
              break;
          }          
        break;
      case 2:
        switch (acct){
          //case 1 in the case is meant for if they do a personal acount and case 2 is if they do a buisness account
            case 1: 
              System.out.print ("How Much Would You Like to Withdrawl?: ");
              withdraw = in.nextInt();
              PA.withdraw(withdraw); //calls on withdrawl function to take money from the account
            break;
            case 2: 
              System.out.print ("How Much Would You Like to Withdrawl?: ");
              withdraw = in.nextInt();
              BA.withdraw(withdraw); //calls on withdrawl function to take money from the account
            break;
          }
        break;
      case 3: 
        switch (acct){
          //case 1 in the case is meant for if they do a personal acount and case 2 is if they do a buisness account
            case 1:
              System.out.print ("How Much Would You Like to Deposit?: ");
              deposit = in.nextInt();
              PA.deposit(deposit);// puts money into the account
            break;
            case 2: 
             System.out.print ("How Much Would You Like to Deposit?: ");
              deposit = in.nextInt();
              BA.deposit(deposit);// puts money into the account
            break;
          }
        break;
      default: quit = 1; 
    }
  }
} 

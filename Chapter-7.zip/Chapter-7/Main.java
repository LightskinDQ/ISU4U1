import java.util.Scanner;
/*
Java Program for Methods
Methods
Dillon Quick
ICS4U1
October 15, 2021
 */
class Main {
  public static void main(String[] args) {
    Scanner in = new Scanner(System.in);
    int qCount = 0;
    int choice = 0;
    String cont = "yes"; // Set variables
    while (cont.equals("yes")) { // created loop so the user can do more than 1 question
      System.out.println("Please type which question you want to see: ");// displays options they can choose from
      System.out.println("2. Metric Conversion");
      System.out.println("5. Add Coins");
      choice = in.nextInt();
      switch (choice) {// created switch statement for the user to choose which question they want to
                       // do
        case (2):
          question2();
          qCount++;
          break;
        case (5):
          System.out.println("Enter your total coins:");
          System.out.println("");
          System.out.println("Pennies:");
          int pennies = in.nextInt();// asks for number of pennies user has
          System.out.println("Nickels:");
          int nickels = in.nextInt();// asks for number of nickels user has
          System.out.println("Dimes:");
          int dimes = in.nextInt();// asks for number of dimes user has
          System.out.println("Quarters:");
          int quarters = in.nextInt();// asks for number of quarters user has

          String answer5 = getDollarAmount(pennies, nickels, dimes, quarters);// calls on method for question
          System.out.println("Total: " + answer5);// prints total
          qCount++;
          break;
        default:// created default option showing if they pick a wrong number they will be sent
                // back into the loop to choose a number listed in the optiond
          System.out.println("You didnt choose a number that corresponds to the options...");

      }
      System.out.println("If you want to do another quesiton type yes");
      cont = in.next().toLowerCase();// makes sure user wants to do another question
    }
    System.out.println("You did " + qCount + " questions. Have a good day :)");// if user said anything other than no
                                                                               // the program will end witht he number
                                                                               // of quesitons they did
  }// main class

  public static void question2() { // Question 2
    /*
     * Question 2 Converts number to a different type of measurment
     */
    Scanner in = new Scanner(System.in);
    double num = 0;
    int answer = 9;
    double conv = 0;// det variables
    System.out.println("Please enter a number");
    num = in.nextInt();// asks user for number
    while (answer > 8) { // loop so if the user enters a number higher than 8 for the choices of what
                         // they want to convert
      // then it will ask the user for the same choices until they pick one that
      // corresponds to the question
      System.out.println("Convert:");
      System.out.println("1. Inches to Cm");
      System.out.println("2. Feet to Cm");
      System.out.println("3. Yards to Meters");
      System.out.println("4. Miles to Km");
      System.out.println("5. Cm to Inches");
      System.out.println("6. Cm to Feet");
      System.out.println("7. Meters to Yards");
      System.out.println("8. Km to Miles");
      System.out.println("Enter your choice");
      answer = in.nextInt();// asks user for which converstion they want to use
      switch (answer) {// created switch statement for the user to choose which conversion they are
                       // doing and the maht behind it
        case (1):// inches to cm
          conv = num * 2.54;
          System.out.println(num + " inches equals " + conv + " cm");
          break;
        case (2):// feet to cm
          conv = num * 30;
          System.out.println(num + " feet equals " + conv + " cm");
          break;
        case (3):// yards to m
          conv = num * 0.91;
          System.out.println(num + " yards equals " + conv + " meters");
          break;
        case (4):// miles to km
          conv = num * 1.6;
          System.out.println(num + " miles equals " + conv + " km");
          break;
        case (5):// cm to inches
          conv = num / 2.54;
          System.out.println(num + " cm equals " + conv + " inches");
          break;
        case (6):
          conv = num / 30;// cm to feet
          System.out.println(num + " cm equals " + conv + " feet");
          break;
        case (7):
          conv = num / 0.91;// m to yards
          System.out.println(num + " meters equals " + conv + " yards");
          break;
        case (8):
          conv = num / 1.6;// km to miles
          System.out.println(num + " km equals " + conv + " miles");
          break;
        default:// shows a defult error statement if the user enters a number higher than 8
          System.out.println("You didnt choose a number that corresponds to the options...");
      }
    }
  }

  public static String getDollarAmount(int pennies, int nickels, int dimes, int quarters) {
    /*
     * Method for question 5 Adds the value of each coin and converts the int to a
     * string and returns that value
     */
    Scanner in = new Scanner(System.in);
    double pennies1 = pennies * 0.01;// converts number of pennnies to the value of the pennies
    double nickels1 = nickels * 0.05;// converts number of nickels to the value of the nickels
    double dimes1 = dimes * 0.1;// converts number of dimes to the value of the dimes
    double quarters1 = quarters * 0.25;// converts number of quarters to the value of the quarters
    double total = pennies1 + nickels1 + dimes1 + quarters1;// adds the total of all the coins

    String total1 = "$" + total;// converts the int to a string
    return total1;// returns total
  }
}
/*
  Exercise2.java
	Counts number of a unigue word is inside file and lists in alpha order
	Dillon Quick 
  ICS4U1
  Dec 17 2021
	*/
import java.util.*;
import java.io.*;

/*
	main method that contians all code to find unique word and list it in alphabetical order.
	Dillon Quick 
  ICS4U1
  Dec 17 2021
	*/
public class Exercise2 {
  void main() {
    TreeMap<String, Integer> h = new TreeMap<>();//frequency table
    String S;
    try{//try-catch for prevent program crashing
      BufferedReader br = new BufferedReader (
        new FileReader ("exercise2.txt")
      );

       while((S = br.readLine())!=null){//reads all lines inside text file
          String arr[] = S.split(" "); //splits s into seperate words
          for(int i =0;i<arr.length;i++){
            arr[i] = arr[i].toLowerCase();//brings to lower case
            if(!h.containsKey(arr[i])){//if does not contain then put 1 beside the new key
              h.put(arr[i],1);
            }else{//otherwise, increment the value for the given key
              h.replace(arr[i], h.get(arr[i])+1);
            }
          }
      }
      System.out.println("WORD:     OCCURENCES: "); //outputs that words and frequency
      for(String x:h.keySet()){//iterating the frequency table
        System.out.println(x+": "+h.get(x));
      }
    }catch(Exception ex){
      System.out.println("An error occurred");
    }
  }
}
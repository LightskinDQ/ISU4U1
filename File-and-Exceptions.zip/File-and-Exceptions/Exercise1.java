/*
  Exercise1.java
	Counts number and average of words inside text file.
	Dillon Quick 
  ICS4U1
  Dec 17 2021
	*/
import java.io.*;
import java.util.*;

class Exercise1 {
/*
	main method that conatins all code that counts number and average of words inside text file.
	Dillon Quick 
  ICS4U1
  Dec 17 2021
	*/
  public static void main(){
    int count = 0;
    int total = 0;
    try {
      BufferedReader br = new BufferedReader ( //creates reader that reads file
        new FileReader ("source.txt")
      );
      String s;
      while ((s = br.readLine()) != null) {  //checks file line by line
        String temp = "";
        for (int i = 0; i < s.length(); i++ ){
          char ch = s.charAt(i);
          if (ch <'A'|| ch > 'Z' && ch < 'a' || ch > 'z'){  //makes sure if the word is a proper word
            if (!temp.equals("")){
              count = count + 1;  //adds to count
              total = total + temp.length();
              temp = "";
              continue;
            }
          }
          temp = temp + ch;

        }
        count = count + 1;
        total = total + temp.length();
      }
      br.close();
      int average = total / count;
      System.out.println ("The number of words is: " + count);  //displays number of words
      System.out.println ("The average of the lengths is: " + average); //displays average of words
    } catch (Exception ex) {
      return;
    }
  }
}
/*
  MainDisplay.java
	Switches Between Questions
	Dillon Quick 
  ICS4U1
  Dec 17 2021
	*/
import java.util.Scanner;
public class MainDisplay {
  /*
	main method that conatins all code that asks user input on what question they want to see. 
	Dillon Quick 
  ICS4U1
  Dec 17 2021
	*/
  public void main (){
    Scanner in = new Scanner(System.in);
    String repeat = "yes"; // variable that defines if the loop repeats
    Exercise1 e1 = new Exercise1();
    Exercise2 e2 = new Exercise2();
    Exercise4 e4 = new Exercise4();
    int choice;
    while (!repeat.equals("no"))   //loop that asks for what question to see
    {
      System.out.println ("Enter 1 for question 1");
      System.out.println ("Enter 2 for question 2"); 
      System.out.println ("Enter 3 for question 4");  
      try {
        choice = in.nextInt();
      }
      catch (Exception ex){
        System.out.println ("Interger was not entered");
        main();
        return;
      }
      switch (choice)    //switch statement to switch between Question Methods
      {
        case 1: e1.main();
        break;
        case 2: e2.main();
        break;
        case 3: e4.main();
        break;
      }
      System.out.println ("");
      System.out.println ("If you wish to continue INPUT yes. If not INPUT no"); 
      repeat = in.next(); //input to ask if user wants to see another question
    }
  }
}
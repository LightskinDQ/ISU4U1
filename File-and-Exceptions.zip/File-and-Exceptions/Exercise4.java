/*
  Exercise4.java
	Adds random verbs and nouns to a story all from files
	Dillon Quick 
  ICS4U1
  Dec 17 2021
	*/

import java.util.*;
import java.io.*;
public class Exercise4 {
  /*
	main method goes line by line finding a # or a % in side story file
	Dillon Quick 
  ICS4U1
  Dec 17 2021
	*/
  public void main() {
    String S;
    try{//try-catch for prevent program crashing
      BufferedReader br = new BufferedReader (
        new FileReader ("story.txt")
      );
      while((S = br.readLine())!=null){//read new lines until the end 
        String arr[] = S.split(" ");//splits the file into seperate words
        for(int i =0;i<arr.length;i++){
          if(arr[i].equals("#")){//replace # with a noun
            arr[i] = getRandomNouns(); //sends to noun method to add random noun
          }else if(arr[i].equals("%")){//replace # with a verb
            arr[i] = getRandomVerbs(); //send to verb method to add random 
          }
        }
        
        //output
        for(String s:arr){
          System.out.print(s+" ");
        }
        System.out.println();
      }
    }catch(Exception ex){
      System.out.println("An error occurred");    
    }
  }
   /*
	creates random int and returns int to replace % with a verb
	Dillon Quick 
  ICS4U1
  Dec 17 2021
	*/
  private String getRandomVerbs(){
    try{//try-catch for prevent program crashing
        BufferedReader br = new BufferedReader (
        new FileReader ("verbs.txt")
      );
      String arr[] = br.readLine().split(" ");//splits verbs into seperate words
      return arr[randInt(0,3)];//pick a random element from 0-3
    }catch (Exception ex){
      System.out.println("An error occurred");
      
    }
    return null;
  }
/*
	creates random int and returns int to replace # with a noun
	Dillon Quick 
  ICS4U1
  Dec 17 2021
	*/
  private String getRandomNouns(){
    try{//try-catch for prevent program crashing
        BufferedReader br = new BufferedReader (
        new FileReader ("nouns.txt")
      );
      String arr[] = br.readLine().split(" ");//splits nouns into seperate words
      return arr[randInt(0,3)];//pick a random element from 0-3
    }catch (Exception ex){
      System.out.println("An error occurred");
      
    }
    return null;
  }

  /*
	creates randInt so its easier to get random int
	Dillon Quick 
  ICS4U1
  Dec 17 2021
	*/
  private int randInt(int min, int max) {
		Random r = new Random();
		return r.nextInt((max - min) + 1) + min;
  }
}
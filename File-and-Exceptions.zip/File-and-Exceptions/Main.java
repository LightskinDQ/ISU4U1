/* 
  Files and Exceptions
  Dillon Quick 
  ICS4U1
  Dec 17 2021
*/
class Main {
  /*
	Main Method Sends to Main Display
	Dillon Quick 
  ICS4U1
  Dec 17 2021
	*/
  public static void main(String[] args) {
    MainDisplay m = new MainDisplay ();
    m.main();
  }
}